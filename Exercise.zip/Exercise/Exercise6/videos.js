const videos = [
  { id: 1, title: "Intro to Node.js", url: "https://example.com/node" },
  { id: 2, title: "Express Basics", url: "https://example.com/express" }
];

module.exports = videos;
